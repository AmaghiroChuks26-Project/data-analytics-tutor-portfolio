# Godswill Amaghiro — Data Analytics Tutor Portfolio

A responsive, single-page portfolio website built with plain HTML and CSS. No build tools or dependencies required.

## Before publishing
1. Open `index.html` and replace `YOUR_EMAIL@example.com` with your professional email address.
2. Review every statement, project description, and credential to ensure it accurately reflects your experience.
3. Add direct links to public repositories or dashboard screenshots where available.

## Publish with GitHub Pages
1. Create a public repository named `portfolio` (or `AmaghiroChuks26-Project.github.io` if you want a user-site URL).
2. Upload `index.html` and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site. The repository's Pages settings will show the published URL.

## Important
The project cards currently describe portfolio case-study areas. Link each card to the actual repository, report, or published dashboard before presenting it as completed work.
